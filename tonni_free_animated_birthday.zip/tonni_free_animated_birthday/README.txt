TONNI FREE ANIMATED BIRTHDAY WEBSITE
====================================
This website is free to use and includes:
- Animated romantic intro with teddy, orbiting rings, sparkles, floating hearts and stars
- Animated page transitions and confetti
- Love letter, six interactive pop balloons, personal photo album
- Interactive star sky and optional generated soft tones (music button)
- All five uploaded photos bundled in assets/

Preview: keep index.html beside the assets folder and open index.html in a browser.

Free publishing option:
1. Extract this ZIP.
2. Visit https://pages.github.com/ and create a free GitHub account/repository.
3. Upload index.html and the entire assets folder to the repository.
4. In repository Settings > Pages, select deploy from the main branch/root. GitHub will show a public URL.
You can also use https://app.netlify.com/drop if its current free deploy flow is available to your account.

No paid service is required for the static site on GitHub Pages. Optional web fonts need internet; all photos and animations are included locally.
